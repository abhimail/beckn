# Migration Notes (v1 → v2)
- Placeholder: capture any breaking renames or enum expansions here.
- Consider splitting `tariffModel` into `pricingBasis` and `pricingModifiers` if needed.