# Changelog
## v1.0.0 — 2025-10-13
- Initial release with item & provider attribute sets
- JSON-LD context and x-jsonld mappings
- Spectral rules and helper function
- Examples and jq adapters