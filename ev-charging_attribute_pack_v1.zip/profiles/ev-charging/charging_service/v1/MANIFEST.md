# Manifest

- Profile ID: `profiles/ev-charging/charging_service/v1`
- Types:
  - ChargingServiceAttributes
  - ChargingProviderAttributes
- Namespaces:
  - schema: https://schema.org/
  - ev: https://schemas.example.org/ev#