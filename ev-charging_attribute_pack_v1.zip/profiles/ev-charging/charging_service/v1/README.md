# EV Charging — Charging Service Attribute Pack (v1)

This pack defines **attributes only** for:
- `ChargingServiceAttributes` (attach to Item.attributes)
- `ChargingProviderAttributes` (attach to Provider.attributes)

It **does not** include Beckn core objects. It aligns fields to **schema.org** via `x-jsonld` and `context.jsonld`.

## Files
- `context.jsonld` — JSON-LD mappings to schema.org & ev namespace
- `attributes.yaml` — OpenAPI 3.1.1 schema for attributes
- `profile.json` — JSON Schema entry points
- `renderer.json` — UI rendering hints
- `rules/` — Spectral and optional Ajv/SHACL validation rules
- `enums/` — code maps & policies
- `tools/` — jq converters for legacy ↔ v1
- `examples/` — working JSON examples

## Attachment points (recommended)
- `Item.attributes` → `ChargingServiceAttributes`
- `Provider.attributes` → `ChargingProviderAttributes`